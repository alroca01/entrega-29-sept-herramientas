//Variables de posición
var positionX = 180;
var positionY = 180;
//Variables de tamaño
var anchocuadrado = 30;
var altocuadrado = 30;

function setup() { 
  createCanvas(400, 400);
} 

function draw() { 
  //Background
  background(100, 133, 255);
  fill (255, 200, 100);
  rect(positionX, positionY, anchocuadrado, altocuadrado);
  
  //Crece el cuadrado en eje X
  if (positionX == 180){
      anchocuadrado++;
      }
  //El cuadrado para de crecer en eje Y
  if (anchocuadrado == 180){
      anchocuadrado--;
      }
  //Crece el cuadrado en eje Y
  if (positionY == 180){
      altocuadrado++;
      }
  //El cuadrado para el eje Y
  if (altocuadrado == 180){
      altocuadrado--;
    //Aquí hay un if dentro de un if 
    // Se le pone Mouseispressed para que cambie la figura
    if (mouseIsPressed){
    fill (80, 171, 82);
    ellipse(280, 280, 50, 50);
  }else{
    fill (197, 47, 54);
    rect(250, 250, 60, 60);
  }
      }
  
}