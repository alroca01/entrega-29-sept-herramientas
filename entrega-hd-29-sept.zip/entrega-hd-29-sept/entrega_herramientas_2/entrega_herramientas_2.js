//variables de posición

var positionX = 20;
var positionX2 = 380;
var positionY = 20;
var positionY2 = 380;

//variables para avanzar
var avanzarX = 0;
var avanzarY = 0;
var avanzarY2 = 0;

//variable para que aparezca segundo círculo
var dibujoY = 0;
var dibujoX2 = 0;
var dibujoY2 = 0;
//variables de color
var r = 232;
var g = 222;
var b = 113;

function setup() { 
  createCanvas

(400, 400);
} 


function draw() { 
  //background
  r = map (positionX, 0, 600, 0, 255);
  b = map (positionY, 0, 600, 255, 0);
  background(r, 0, b);
  // Dibujo circulo 1
  fill (r, g, b, 200);
  ellipse (positionX, 20, 40, 40);
  //ellipse (380, positionY, 40, 40);
   
//movimiento horizontal circulo 1 
  
  if (positionX == 20){
    positionX++;
    avanzarX = 1;
  }
  
  if (avanzarX == 1){
    positionX++;
  }
  else{
    positionX --;
  }
  
  // Circulo 1 golpea borde, dibujar circulo 2
  
  if (positionX == width-20){
    positionX--;
    avanzarX = 0;
    dibujoY = 1;
  }
  
  if (dibujoY == 1) {  
      //dibujo circulo 2
      fill (r, g, b, 150);
     
    ellipse (379, positionY, 40, 40);
    
    //Cuadro 2 se mueve en eje Y
  if (positionY == 20){
      positionY++;
      avanzarY = 1;  
  }
      
  if (avanzarY == 1){
     
      positionY++;
      }else{
      positionY--;  

  }
  if (positionY == height-20){
      positionY--;
      avanzarY = 0;
      dibujoX2 = 1;
  }
  }
  
  if (dibujoX2 == 1) {  
      //dibujo circulo 2
      fill (r, g, b, 100);
     
    ellipse (positionX2, 380, 40, 40);
    
    //Cuadro 2 se mueve en eje Y
  if (positionX2 == 380){
      positionX2--;
      avanzarX2 = 0;  
  }
      
  if (avanzarX2 == 0){
     
      positionX2--;
      }else{
      positionX2++;  

  }
  if (positionX2 == 20){
      positionX2++;
      avanzarX2 = 1;
      dibujoY2 = 1;
  }
  }
  
  if (dibujoY2 == 1) {  
      //dibujo circulo 2
      fill (r, g, b, 50);
     
    ellipse (20, positionY2, 40, 40);
    
    //Cuadro 2 se mueve en eje Y
  if (positionY2 == 380){
      positionY2--;
      avanzarY2 = 0;  
  }
      
  if (avanzarY2 == 0){
     
      positionY2--;
      }else{
      positionY2++;  

  }
  if (positionY2 == 20){
      positionY2++;
      avanzarY2 = 1;
  }
  }
}