//Variables de posición
var x = 200;
var y = 200;
//Variables de tamaño
var circuloX = 30;
var circuloY = 30;
//Variables de color
var r = 242;
var g = 236;
var b = 77;

function setup() { 
  createCanvas(400, 400);
} 

function draw() { 
  //Background
  background(100, 133, 255);
  //Dibujo ellipse
  fill (r, g, b);
  ellipse (x, y, circuloX, circuloY);
  
  //Crece el círculo en eje X
  if (x == 200){
      circuloX++;
      }
  //Crece el círculo en eje X
  if (y == 200){
      circuloY++;
      }
  //El círculo para de crecer en X
  if (circuloX == 250){
      circuloX--;
      }
  //El círculo para de crecer en Y
  if (circuloY == 250){
      circuloY--;
    //El círculo se enloquece
    x = random (0, 400);
      }
}